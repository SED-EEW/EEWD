package net.ser1.stomp;

/*
 * (c)2005 Sean Russell
 */
public class FileQueue implements Queue {
  public FileQueue() {
  }
}
