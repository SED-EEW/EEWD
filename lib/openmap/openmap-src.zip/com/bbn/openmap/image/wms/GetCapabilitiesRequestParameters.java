package com.bbn.openmap.image.wms;

class GetCapabilitiesRequestParameters extends WmsRequestParameters {

}
