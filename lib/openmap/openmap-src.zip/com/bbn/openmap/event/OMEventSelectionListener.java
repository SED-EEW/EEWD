//**********************************************************************
//
//<copyright>
//
//BBN Technologies, a Verizon Company
//10 Moulton Street
//Cambridge, MA 02138
//(617) 873-8000
//
//Copyright (C) BBNT Solutions LLC. All rights reserved.
//
//</copyright>
//**********************************************************************
//
//$Source:
///cvs/darwars/ambush/aar/src/com/bbn/ambush/mission/MissionHandler.java,v
//$
//$RCSfile: AAREventSelectionListener.java,v $
//$Revision: 1.1 $
//$Date: 2007/08/16 22:15:31 $
//$Author: dietrick $
//
//**********************************************************************

package com.bbn.openmap.event;


public interface OMEventSelectionListener {
    public void selected(OMEvent omEvent);
}
